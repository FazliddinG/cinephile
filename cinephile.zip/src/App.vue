<template>
  <div>
    <Navbar/>
    <router-view></router-view>
  </div>
</template>

<script setup>
import Navbar from './components/Navbar/Navbar.vue';

</script>

<style lang="scss" scoped>

</style>