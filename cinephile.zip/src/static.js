export const options = {
    method: 'GET',
    headers: {
      accept: 'application/json',
      Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI1OTYyOGNhZGFkZjBmYmFjMWU3OWFkNDQ2NTNkYzIzMiIsInN1YiI6IjYzOWMzNGFmODFhN2ZjMDBhMjY0MTRiNCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.5C10QBpt4J1DB-rJwd5nyuVwtuCL4zXuPKtlBj2GhtA'
    }
  };
  
export const imgUrl = 'https://image.tmdb.org/t/p/w500';
export const imgUrlFull = 'https://image.tmdb.org/t/p/original'